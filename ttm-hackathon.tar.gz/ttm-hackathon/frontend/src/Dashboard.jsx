import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import ChatWidget from './ChatWidget';

const statusMapRu = {
  new: 'Новая',
  in_progress: 'В работе',
  on_approval: 'На согласовании',
  done: 'Выполнена',
  overdue: 'Просрочена'
};

function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showChat, setShowChat] = useState(false);

  useEffect(() => {
    fetch('/api/dashboard/stats')
      .then(res => res.json())
      .then(data => {
        setStats(data);
        setLoading(false);
      })
      .catch(err => console.error(err));
  }, []);

  if (loading) return <div className="text-white p-4 text-center">Загрузка статистики...</div>;

  const statusData = Object.entries(stats.status_counts).map(([key, value]) => ({
    name: statusMapRu[key] || key,
    value: value
  }));
  const userData = Object.entries(stats.user_tasks).map(([name, tasks]) => ({ name, tasks }));
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

  return (
    <>
      <div className="card-glass p-4 sm:p-6">
        <div className="flex justify-between items-center flex-wrap gap-3 mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-white">Дашборд аналитики</h1>
          <button
            onClick={() => setShowChat(true)}
            style={{
              background: 'linear-gradient(135deg, #8b5cf6, #6d28d9)',
              border: 'none',
              color: 'white',
              fontWeight: 'bold',
              padding: '8px 20px',
              borderRadius: '9999px',
              cursor: 'pointer'
            }}
          >
            💬 Чат с AI
          </button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-black/30 backdrop-blur-sm p-4 rounded-2xl">
            <h2 className="text-xl font-semibold text-white text-center mb-2">Распределение по статусам</h2>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                  {statusData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-black/30 backdrop-blur-sm p-4 rounded-2xl">
            <h2 className="text-xl font-semibold text-white text-center mb-2">Загрузка сотрудников</h2>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={userData}>
                <XAxis dataKey="name" stroke="#ccc" />
                <YAxis stroke="#ccc" />
                <Tooltip />
                <Legend />
                <Bar dataKey="tasks" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-black/30 backdrop-blur-sm p-4 rounded-2xl flex flex-col sm:flex-row justify-between gap-4">
          <div className="text-center sm:text-left">
            <p className="font-bold text-white text-lg">Всего задач: {stats.total_tasks}</p>
            <p className="font-bold text-red-300 text-lg">Просроченных: {stats.overdue_tasks}</p>
          </div>
        </div>
      </div>
      {showChat && createPortal(
        <ChatWidget onClose={() => setShowChat(false)} />,
        document.body
      )}
    </>
  );
}

export default Dashboard;

