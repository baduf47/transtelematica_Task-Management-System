import { useState, useEffect } from 'react';

function TaskForm({ onTaskCreated, onClose }) {
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'new',
    priority: 'medium',
    period: 'month',
    deadline: '',
    department: '',
    assignee_id: 1,
  });

  useEffect(() => {
    fetch('/api/users')
      .then(res => res.json())
      .then(data => setUsers(data))
      .catch(err => console.error(err));
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        onTaskCreated();
        onClose();
      } else {
        alert('Ошибка создания задачи');
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl shadow-2xl w-full max-w-md p-6 border border-white/30">
        <h2 className="text-2xl font-bold text-white mb-5 text-center">✨ Создать задачу</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-200 mb-1 font-medium">Название</label>
            <input name="title" value={formData.title} onChange={handleChange} required className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30 focus:border-blue-400 focus:outline-none" />
          </div>
          <div className="mb-4">
            <label className="block text-gray-200 mb-1 font-medium">Описание</label>
            <textarea name="description" value={formData.description} onChange={handleChange} rows="3" className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30 focus:border-blue-400 focus:outline-none" />
          </div>
          <div className="mb-4">
            <label className="block text-gray-200 mb-1 font-medium">Ответственный</label>
            <select name="assignee_id" value={formData.assignee_id} onChange={handleChange} className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30">
              {users.map(user => (
                <option key={user.id} value={user.id}>{user.name} ({user.department})</option>
              ))}
            </select>
          </div>
          <div className="mb-4">
            <label className="block text-gray-200 mb-1 font-medium">Отдел</label>
            <input name="department" value={formData.department} onChange={handleChange} required className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30" />
          </div>
          <div className="mb-4">
            <label className="block text-gray-200 mb-1 font-medium">Период</label>
            <select name="period" value={formData.period} onChange={handleChange} className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30">
              <option value="year">Год</option>
              <option value="quarter">Квартал</option>
              <option value="month">Месяц</option>
              <option value="week">Неделя</option>
            </select>
          </div>
          <div className="mb-4">
            <label className="block text-gray-200 mb-1 font-medium">Дедлайн</label>
            <input type="date" name="deadline" value={formData.deadline} onChange={handleChange} required className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30" />
          </div>
          <div className="mb-4">
            <label className="block text-gray-200 mb-1 font-medium">Приоритет</label>
            <select name="priority" value={formData.priority} onChange={handleChange} className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30">
              <option value="low">Низкий</option>
              <option value="medium">Средний</option>
              <option value="high">Высокий</option>
            </select>
          </div>
          <div className="mb-5">
            <label className="block text-gray-200 mb-1 font-medium">Статус</label>
            <select name="status" value={formData.status} onChange={handleChange} className="w-full p-2 rounded-xl bg-white/10 text-white border border-white/30">
              <option value="new">Новая</option>
              <option value="in_progress">В работе</option>
              <option value="on_approval">На согласовании</option>
              <option value="done">Выполнена</option>
              <option value="overdue">Просрочена</option>
            </select>
          </div>
          <div className="flex gap-3 justify-end">
            <button type="button" onClick={onClose} className="bg-gray-600 hover:bg-gray-700 text-white px-5 py-2 rounded-xl transition">Отмена</button>
            <button type="submit" className="bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 text-white px-5 py-2 rounded-xl transition">Создать</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default TaskForm;

