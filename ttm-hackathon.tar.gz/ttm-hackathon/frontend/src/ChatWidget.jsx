import { useState, useEffect, useRef } from 'react';

function ChatWidget({ onClose }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (text) => {
    if (!text.trim()) return;
    const userMsg = { role: 'user', content: text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, userMsg] })
      });
      const data = await response.json();
      setMessages(prev => [...prev, { role: 'assistant', content: data.response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Ошибка соединения с AI.' }]);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = () => sendMessage(input);
  const handleAnalyze = () => sendMessage('Проанализируй текущие задачи и дай рекомендации руководителю.');

  // Кнопка «Показать чат» (когда свёрнут)
  if (minimized) {
    return (
      <button
        onClick={() => setMinimized(false)}
        style={{
          position: 'fixed',
          bottom: '32px',
          right: '32px',
          zIndex: 9999,
          backgroundColor: '#2563eb',
          color: 'white',
          borderRadius: '9999px',
          padding: '12px 18px',
          border: 'none',
          fontWeight: 'bold',
          cursor: 'pointer',
          boxShadow: '0 10px 15px -3px rgba(0,0,0,0.3)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          fontSize: '14px'
        }}
      >
        💬 Показать чат
      </button>
    );
  }

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '32px',
        right: '32px',
        zIndex: 9999,
        width: '400px',
        minWidth: '280px',
        maxWidth: '600px',
        height: '600px',
        minHeight: '400px',
        maxHeight: '80vh',
        resize: 'both',               // позволяет менять размер мышкой
        overflow: 'auto',
        background: 'linear-gradient(135deg, #111827, #1f2937)',
        borderRadius: '1rem',
        boxShadow: '0 25px 40px rgba(0,0,0,0.5)',
        border: '1px solid rgba(255,255,255,0.2)',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: 'rgba(0,0,0,0.5)', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
        <h3 style={{ color: 'white', fontSize: '18px', fontWeight: 'bold', margin: 0 }}>🤖 AI-помощник</h3>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button onClick={() => setMinimized(true)} style={{ background: 'rgba(255,255,255,0.1)', border: 'none', color: 'white', padding: '4px 12px', borderRadius: '20px', cursor: 'pointer' }}>Свернуть</button>
          <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.1)', border: 'none', color: 'white', padding: '4px 12px', borderRadius: '20px', cursor: 'pointer' }}>Закрыть</button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {messages.length === 0 && (
          <div style={{ textAlign: 'center', color: 'rgba(255,255,255,0.5)', marginTop: '40px' }}>
            <p>Задайте вопрос о задачах или нажмите «Анализ задач»</p>
          </div>
        )}
        {messages.map((msg, idx) => (
          <div key={idx} style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
            <div style={{
              maxWidth: '80%',
              borderRadius: '20px',
              padding: '8px 14px',
              backgroundColor: msg.role === 'user' ? '#2563eb' : '#374151',
              color: 'white'
            }}>
              <p style={{ margin: 0, fontSize: '14px', wordBreak: 'break-word' }}>{msg.content}</p>
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
            <div style={{ backgroundColor: '#374151', borderRadius: '20px', padding: '8px 14px', color: '#ccc', fontStyle: 'italic' }}>AI печатает...</div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div style={{ padding: '12px', borderTop: '1px solid rgba(255,255,255,0.1)', background: 'rgba(0,0,0,0.3)' }}>
        <button onClick={handleAnalyze} disabled={loading} style={{
          width: '100%',
          backgroundColor: '#4f46e5',
          border: 'none',
          color: 'white',
          padding: '8px',
          borderRadius: '40px',
          fontWeight: 'bold',
          marginBottom: '12px',
          cursor: 'pointer'
        }}>
          🔍 Анализ задач
        </button>
        <div style={{ display: 'flex', gap: '8px' }}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !loading && handleSend()}
            placeholder="Задайте вопрос..."
            style={{
              flex: 1,
              padding: '8px 12px',
              borderRadius: '40px',
              border: '1px solid rgba(255,255,255,0.3)',
              background: 'rgba(255,255,255,0.1)',
              color: 'white',
              outline: 'none'
            }}
            disabled={loading}
          />
          <button onClick={handleSend} disabled={loading || !input.trim()} style={{
            backgroundColor: '#2563eb',
            border: 'none',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '40px',
            fontWeight: 'bold',
            cursor: 'pointer'
          }}>
            Отправить
          </button>
        </div>
      </div>
    </div>
  );
}

export default ChatWidget;

