import { useEffect, useState } from 'react';
import TaskForm from './TaskForm';

// Функции преобразования статусов, приоритетов, периодов в русский текст
const statusMap = {
  new: 'Новая',
  in_progress: 'В работе',
  on_approval: 'На согласовании',
  done: 'Выполнена',
  overdue: 'Просрочена'
};

const priorityMap = {
  low: 'Низкий',
  medium: 'Средний',
  high: 'Высокий'
};

const periodMap = {
  year: 'Год',
  quarter: 'Квартал',
  month: 'Месяц',
  week: 'Неделя'
};

function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [filters, setFilters] = useState({
    status: '',
    period: '',
    department: '',
    assignee_id: ''
  });

  const fetchTasks = () => {
    const params = new URLSearchParams();
    if (filters.status) params.append('status', filters.status);
    if (filters.period) params.append('period', filters.period);
    if (filters.department) params.append('department', filters.department);
    if (filters.assignee_id) params.append('assignee_id', filters.assignee_id);
    
    fetch(`/api/tasks?${params.toString()}`)
      .then(res => res.json())
      .then(data => {
        setTasks(data);
        setLoading(false);
      })
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchTasks();
    fetch('/api/users')
      .then(res => res.json())
      .then(data => setUsers(data))
      .catch(err => console.error(err));
  }, [filters]);

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const getUserName = (id) => {
    const user = users.find(u => u.id === id);
    return user ? `${user.name} (${user.role === 'team_lead' ? 'рук.' : 'сотр.'})` : `ID ${id}`;
  };

  const formatDate = (dateStr) => {
    const [year, month, day] = dateStr.split('-');
    return `${day}.${month}.${year}`;
  };

  if (loading) return <div className="text-white p-4 text-center">Загрузка задач...</div>;

  return (
    <div className="card-glass p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Список задач</h1>
        <button onClick={() => setShowForm(true)} className="btn-primary">+ Новая задача</button>
      </div>

      <div className="flex flex-wrap gap-3 mb-6">
        <select name="status" value={filters.status} onChange={handleFilterChange} className="filter-select">
          <option value="">Все статусы</option>
          <option value="new">Новая</option>
          <option value="in_progress">В работе</option>
          <option value="on_approval">На согласовании</option>
          <option value="done">Выполнена</option>
          <option value="overdue">Просрочена</option>
        </select>
        <select name="period" value={filters.period} onChange={handleFilterChange} className="filter-select">
          <option value="">Все периоды</option>
          <option value="year">Год</option>
          <option value="quarter">Квартал</option>
          <option value="month">Месяц</option>
          <option value="week">Неделя</option>
        </select>
        <select name="department" value={filters.department} onChange={handleFilterChange} className="filter-select">
          <option value="">Все отделы</option>
          <option value="Молодые таланты">Молодые таланты</option>
          <option value="АХО">АХО</option>
          <option value="HR">HR</option>
          <option value="ИТ">ИТ</option>
          <option value="Финансы">Финансы</option>
        </select>
        <select name="assignee_id" value={filters.assignee_id} onChange={handleFilterChange} className="filter-select">
          <option value="">Все сотрудники</option>
          {users.map(user => (
            <option key={user.id} value={user.id}>{user.name}</option>
          ))}
        </select>
      </div>

      <div className="table-wrapper">
        <table className="table-glass">
          <thead>
            <tr>
              <th>Название</th>
              <th>Статус</th>
              <th>Приоритет</th>
              <th>Период</th>
              <th>Дедлайн</th>
              <th>Отдел</th>
              <th>Ответственный</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map(task => (
              <tr key={task.id}>
                <td>{task.title}</td>
                <td>{statusMap[task.status] || task.status}</td>
                <td>{priorityMap[task.priority] || task.priority}</td>
                <td>{periodMap[task.period] || task.period}</td>
                <td>{formatDate(task.deadline)}</td>
                <td>{task.department}</td>
                <td>{getUserName(task.assignee_id)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && <TaskForm onTaskCreated={fetchTasks} onClose={() => setShowForm(false)} />}
    </div>
  );
}

export default TaskList;

