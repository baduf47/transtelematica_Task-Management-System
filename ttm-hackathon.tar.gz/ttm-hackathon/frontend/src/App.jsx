import { BrowserRouter, Routes, Route } from 'react-router-dom';
import TaskList from './TaskList';
import Dashboard from './Dashboard';
import logo from './assets/logo.png';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col">
        <header className="sticky top-0 z-20 bg-black/50 backdrop-blur-md shadow-lg py-4">
          <div className="container mx-auto px-6 flex flex-wrap justify-between items-center gap-4">
            <div className="flex items-center gap-4">
              <img src={logo} alt="Логотип" className="h-12 w-auto" />
              <span className="text-white text-2xl font-bold tracking-wide">
                Транстелематика: <span className="font-normal">система управления задачами</span>
              </span>
            </div>
            <nav className="flex gap-4">
              <button
                onClick={() => window.location.href = '/'}
                style={{
                  backgroundColor: '#2563eb',
                  color: 'white',
                  padding: '8px 24px',
                  borderRadius: '9999px',
                  border: 'none',
                  fontWeight: 'bold',
                  fontSize: '16px',
                  cursor: 'pointer',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
                }}
              >
                Список задач
              </button>
              <button
                onClick={() => window.location.href = '/dashboard'}
                style={{
                  backgroundColor: '#6d28d9',
                  color: 'white',
                  padding: '8px 24px',
                  borderRadius: '9999px',
                  border: 'none',
                  fontWeight: 'bold',
                  fontSize: '16px',
                  cursor: 'pointer',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
                }}
              >
                Дашборд
              </button>
            </nav>
          </div>
        </header>
        <main className="container mx-auto px-6 py-8 flex-grow">
          <Routes>
            <Route path="/" element={<TaskList />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;

