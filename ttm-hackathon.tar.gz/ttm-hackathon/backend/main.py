import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, text
from database import engine, Base, get_db, AsyncSessionLocal
from models import User, Task, TaskStatus, Priority, Period
from pydantic import BaseModel
from datetime import date
from typing import Optional, List
import httpx


# ========== Ожидание готовности БД ==========
async def wait_for_db(max_retries=30, delay=2):
    for i in range(max_retries):
        try:
            async with AsyncSessionLocal() as session:
                await session.execute(text("SELECT 1"))
            print("✅ Database ready")
            return
        except Exception as e:
            print(f"⏳ Waiting for DB... ({i+1}/{max_retries}) - {e}")
            await asyncio.sleep(delay)
    raise Exception("❌ Could not connect to PostgreSQL")


# ========== Pydantic модели ==========
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    status: TaskStatus = TaskStatus.NEW
    priority: Priority = Priority.MEDIUM
    period: Period
    deadline: date
    department: str
    assignee_id: int
    parent_task_id: Optional[int] = None


class TaskResponse(TaskCreate):
    id: int


class UserResponse(BaseModel):
    id: int
    name: str
    role: str
    department: str


# Модели для чата
class ChatMessage(BaseModel):
    role: str  # "user" или "assistant"
    content: str


class ChatRequest(BaseModel):
    messages: List[ChatMessage]


# ========== Lifespan ==========
@asynccontextmanager
async def lifespan(app: FastAPI):
    await wait_for_db()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User))
        if not result.scalars().first():
            users_data = [
                {"name": "Иван", "role": "team_lead", "department": "Молодые таланты"},
                {"name": "Мария", "role": "employee", "department": "АХО"},
                {"name": "Алексей", "role": "employee", "department": "АХО"},
                {"name": "Ольга", "role": "team_lead", "department": "HR"},
                {"name": "Анна", "role": "employee", "department": "HR"},
                {"name": "Дмитрий", "role": "employee", "department": "ИТ"},
                {"name": "Елена", "role": "employee", "department": "Финансы"},
            ]
            for u in users_data:
                session.add(User(**u))
            await session.commit()
    yield
    await engine.dispose()


# ========== FastAPI приложение ==========
app = FastAPI(title="Task Manager API", lifespan=lifespan)


# CORS для фронтенда
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"message": "Task Manager API is running"}


# ---------- Пользователи ----------
@app.get("/users", response_model=List[UserResponse])
async def list_users(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User))
    return result.scalars().all()


# ---------- Задачи ----------
@app.get("/tasks", response_model=List[TaskResponse])
async def list_tasks(
    db: AsyncSession = Depends(get_db),
    status: Optional[str] = None,
    period: Optional[str] = None,
    department: Optional[str] = None,
    assignee_id: Optional[int] = None
):
    query = select(Task)
    if status:
        query = query.where(Task.status == status)
    if period:
        query = query.where(Task.period == period)
    if department:
        query = query.where(Task.department == department)
    if assignee_id:
        query = query.where(Task.assignee_id == assignee_id)
    result = await db.execute(query)
    return result.scalars().all()


@app.post("/tasks", response_model=TaskResponse)
async def create_task(task: TaskCreate, db: AsyncSession = Depends(get_db)):
    db_task = Task(**task.dict())
    db.add(db_task)
    await db.commit()
    await db.refresh(db_task)
    return db_task


@app.get("/tasks/{task_id}", response_model=TaskResponse)
async def get_task(task_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@app.put("/tasks/{task_id}")
async def update_task(task_id: int, task_update: TaskCreate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    for key, value in task_update.dict().items():
        setattr(task, key, value)
    await db.commit()
    return {"message": "Task updated"}


@app.delete("/tasks/{task_id}")
async def delete_task(task_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    await db.delete(task)
    await db.commit()
    return {"message": "Task deleted"}


# ---------- Дашборд ----------
@app.get("/dashboard/stats")
async def dashboard_stats(db: AsyncSession = Depends(get_db)):
    total = await db.scalar(select(func.count()).select_from(Task))
    status_counts = {}
    for status in TaskStatus:
        cnt = await db.scalar(select(func.count()).where(Task.status == status))
        status_counts[status.value] = cnt or 0
    today = date.today()
    overdue = await db.scalar(select(func.count()).where(Task.deadline < today, Task.status != TaskStatus.DONE))
    users = await db.execute(select(User))
    user_tasks = {}
    for user in users.scalars().all():
        cnt = await db.scalar(select(func.count()).where(Task.assignee_id == user.id))
        user_tasks[user.name] = cnt or 0
    return {
        "total_tasks": total,
        "status_counts": status_counts,
        "overdue_tasks": overdue or 0,
        "user_tasks": user_tasks
    }


# ---------- AI тест ----------
@app.get("/ai/test")
async def test_ai():
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "http://ollama:11434/api/generate",
            json={"model": "llama3.2:3b", "prompt": "Напиши одно предложение приветствия для руководителя", "stream": False},
            timeout=30.0
        )
        return resp.json()


# ---------- AI суммарный анализ (простая кнопка) ----------
@app.get("/ai/summary")
async def ai_summary(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task))
    tasks = result.scalars().all()
    if not tasks:
        return {"analysis": "Нет задач для анализа."}
    sample = tasks[:3]
    prompt = f"Коротко проанализируй задачи: {[(t.title, t.status.value, t.deadline) for t in sample]}. Выдай одну-две фразы для руководителя."
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(180.0)) as client:
            resp = await client.post(
                "http://ollama:11434/api/generate",
                json={"model": "llama3.2:3b", "prompt": prompt, "stream": False}
            )
            return {"analysis": resp.json().get("response", "Ошибка генерации")}
    except Exception as e:
        return {"analysis": f"Ошибка AI: {str(e)}"}


# ---------- AI чат (с историей и полным контекстом) ----------
@app.post("/ai/chat")
async def chat(request: ChatRequest, db: AsyncSession = Depends(get_db)):
    # Получаем актуальные данные из БД
    tasks_result = await db.execute(select(Task).limit(20))
    tasks = tasks_result.scalars().all()
    
    users_result = await db.execute(select(User))
    users = users_result.scalars().all()
    user_task_counts = {}
    for user in users:
        cnt = await db.scalar(select(func.count()).where(Task.assignee_id == user.id))
        user_task_counts[user.name] = cnt or 0
    
    today = date.today()
    overdue_count = await db.scalar(select(func.count()).where(Task.deadline < today, Task.status != TaskStatus.DONE))
    
    tasks_summary = []
    for t in tasks[:10]:
        tasks_summary.append(f"- {t.title} (статус: {t.status.value}, дедлайн: {t.deadline}, ответственный ID {t.assignee_id})")
    tasks_text = "\n".join(tasks_summary) if tasks_summary else "Нет задач."
    
    user_load_text = "\n".join([f"{name}: {count} задач" for name, count in user_task_counts.items()])
    
    system_prompt = f"""Ты — AI-помощник руководителя в системе управления задачами. Твоя задача помогать анализировать задачи, выявлять риски, перегрузку сотрудников и давать рекомендации.


### Текущие данные из системы:
**Задачи (последние 10):**
{tasks_text}


**Загрузка сотрудников:**
{user_load_text}


**Просроченных задач:** {overdue_count}


### Правила:
- Отвечай кратко и по делу (2-5 предложений).
- Если задают вопрос не по задачам, вежливо направляй к теме.
- Для анализа задач по кнопке "Анализ задач" пользователь попросит тебя это сделать. Ты можешь сам предложить анализ на основе данных выше.
- Если появились новые задачи после предыдущего диалога, упомяни это (но мы обновляем данные каждый запрос, так что ты видишь актуальное состояние).


Теперь ответь пользователю.
"""
    
    # Собираем полную историю с системным промптом
    full_messages = [{"role": "system", "content": system_prompt}]
    for msg in request.messages:
        full_messages.append({"role": msg.role, "content": msg.content})
    
    # Преобразуем в один длинный промпт для Ollama
    prompt_for_ollama = ""
    for msg in full_messages:
        role = msg["role"]
        content = msg["content"]
        if role == "system":
            prompt_for_ollama += f"System: {content}\n"
        elif role == "user":
            prompt_for_ollama += f"User: {content}\n"
        elif role == "assistant":
            prompt_for_ollama += f"Assistant: {content}\n"
    prompt_for_ollama += "Assistant: "
    
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(180.0)) as client:
            resp = await client.post(
                "http://ollama:11434/api/generate",
                json={"model": "llama3.2:3b", "prompt": prompt_for_ollama, "stream": False}
            )
            answer = resp.json().get("response", "Извините, не удалось сгенерировать ответ.")
            return {"response": answer}
    except Exception as e:
        return {"response": f"Ошибка AI: {str(e)}"}

