from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from contextlib import asynccontextmanager
from database import engine, Base, get_db
from models import User, Task, TaskStatus, Priority, Period
from pydantic import BaseModel
from datetime import date
from typing import Optional, List
import httpx

import asyncio
async def wait_for_db():
    from sqlalchemy import text
    from database import AsyncSessionLocal
    for i in range(30):
        try:
            async with AsyncSessionLocal() as session:
                await session.execute(text("SELECT 1"))
            print("Database ready")
            return
        except Exception as e:
            print(f"Waiting for DB... {e}")
            await asyncio.sleep(2)
    raise Exception("Could not connect to DB")



# ========== Pydantic модели (DTO) ==========
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    status: TaskStatus = TaskStatus.NEW
    priority: Priority = Priority.MEDIUM
    period: Period
    deadline: date
    department: str
    assignee_id: int          # ← идентификатор ответственного пользователя
    parent_task_id: Optional[int] = None

class TaskResponse(TaskCreate):
    id: int

class UserResponse(BaseModel):
    id: int
    name: str
    role: str
    department: str

# ========== Lifespan: создание таблиц и тестовых данных ==========
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Создаём таблицы в БД
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Добавляем тестовых пользователей, если их ещё нет
    async with AsyncSession(engine) as session:
        result = await session.execute(select(User))
        if not result.scalars().first():
            users_data = [
                {"name": "Иван", "role": "team_lead", "department": "Молодые таланты"},
                {"name": "Мария", "role": "employee", "department": "АХО"},
                {"name": "Алексей", "role": "employee", "department": "АХО"},
                {"name": "Ольга", "role": "team_lead", "department": "HR"},
                {"name": "Анна", "role": "employee", "department": "HR"},
                {"name": "Дмитрий", "role": "employee", "department": "ИТ"},
                {"name": "Елена", "role": "employee", "department": "Финансы"},
            ]
            for u in users_data:
                session.add(User(**u))
            await session.commit()
    yield
    await engine.dispose()
# ========== FastAPI приложение ==========
app = FastAPI(title="Task Manager API", lifespan=lifespan)

@app.get("/")
def root():
    return {"message": "Task Manager API is running"}

# ---------- Пользователи ----------
@app.get("/users", response_model=List[UserResponse])
async def list_users(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User))
    users = result.scalars().all()
    return users

# ---------- Задачи (CRUD) ----------
@app.get("/tasks", response_model=List[TaskResponse])
async def list_tasks(
    db: AsyncSession = Depends(get_db),
    department: Optional[str] = None,
    status: Optional[TaskStatus] = None,
    period: Optional[Period] = None,
    assignee_id: Optional[int] = None,
    priority: Optional[Priority] = None,
):
    query = select(Task)
    if department:
        query = query.where(Task.department == department)
    if status:
        query = query.where(Task.status == status)
    if period:
        query = query.where(Task.period == period)
    if assignee_id:
        query = query.where(Task.assignee_id == assignee_id)
    if priority:
        query = query.where(Task.priority == priority)
    result = await db.execute(query)
    tasks = result.scalars().all()
    return tasks

@app.get("/tasks/{task_id}/children")
async def get_children(task_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.parent_task_id == task_id))
    children = result.scalars().all()
    return children

@app.post("/tasks", response_model=TaskResponse)
async def create_task(task: TaskCreate, db: AsyncSession = Depends(get_db)):
    db_task = Task(**task.dict())
    db.add(db_task)
    await db.commit()
    await db.refresh(db_task)
    return db_task

@app.get("/tasks/{task_id}", response_model=TaskResponse)
async def get_task(task_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.get("/tasks/{task_id}/progress")
async def get_progress(task_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.parent_task_id == task_id))
    children = result.scalars().all()
    if not children:
        return {"progress": 0, "total": 0}
    done = sum(1 for t in children if t.status == TaskStatus.DONE)
    total = len(children)
    return {"progress": round(done/total*100, 2), "done": done, "total": total}


@app.put("/tasks/{task_id}")
async def update_task(task_id: int, task_update: TaskCreate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    for key, value in task_update.dict().items():
        setattr(task, key, value)
    await db.commit()
    return {"message": "Task updated"}

@app.delete("/tasks/{task_id}")
async def delete_task(task_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    await db.delete(task)
    await db.commit()
    return {"message": "Task deleted"}

# ---------- Дашборд (базовая статистика) ----------
@app.get("/dashboard/stats")
async def dashboard_stats(db: AsyncSession = Depends(get_db)):
    total_tasks = await db.scalar(select(func.count()).select_from(Task))
    status_counts = {}
    for status in TaskStatus:
        count = await db.scalar(select(func.count()).where(Task.status == status))
        status_counts[status.value] = count or 0
    today = date.today()
    overdue = await db.scalar(select(func.count()).where(Task.deadline < today, Task.status != TaskStatus.DONE))
    users = await db.execute(select(User))
    user_tasks = {}
    for user in users.scalars().all():
        cnt = await db.scalar(select(func.count()).where(Task.assignee_id == user.id))
        user_tasks[user.name] = cnt or 0
    return {
        "total_tasks": total_tasks,
        "status_counts": status_counts,
        "overdue_tasks": overdue or 0,
        "user_tasks": user_tasks
    }

# ---------- AI тест (проверка связи с Ollama) ----------
@app.get("/ai/test")
async def test_ai():
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "http://ollama:11434/api/generate",
            json={"model": "llama3.2:3b", "prompt": "Напиши одно предложение приветствия для руководителя", "stream": False},
            timeout=30.0
        )
        return resp.json()

@app.get("/ai/summary")
async def ai_summary(db: AsyncSession = Depends(get_db)):
    # Получаем все задачи из БД
    result = await db.execute(select(Task))
    tasks = result.scalars().all()
    if not tasks:
        return {"analysis": "Задач пока нет. Создайте задачи для получения AI-анализа."}
    # Формируем информативный промпт для модели
    tasks_summary = []
    for t in tasks[:10]:  # Ограничим 10 задачами для экономии времени
        tasks_summary.append(f"Задача: {t.title}, статус: {t.status.value}, приоритет: {t.priority.value}, дедлайн: {t.deadline}, ответственный ID: {t.assignee_id}")
    prompt = f"""
    Ты — AI-помощник руководителя. Проанализируй следующие задачи:
    {chr(10).join(tasks_summary)}
    Выдай короткий анализ (3-5 предложений), в котором:
    - Укажи задачи с риском просрочки (если дедлайн близко или уже просрочены)
    - Назови перегруженных сотрудников (у кого больше 3 задач)
    - Дай рекомендацию руководителю, на что обратить внимание.
    """
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "http://ollama:11434/api/generate",
            json={"model": "llama3.2:3b", "prompt": prompt, "stream": False},
            timeout=240.0
        )
    response_text = resp.json().get("response", "Ошибка генерации ответа")
    return {"analysis": response_text}
