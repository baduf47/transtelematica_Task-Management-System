--
-- PostgreSQL database dump
--

\restrict OvqnfDD7kKSyot4gAOjJK7Ozw24bMYtfaGY3e9wMZdcy2cxhhO91ESBAI2Xxbev

-- Dumped from database version 15.18 (Debian 15.18-1.pgdg13+1)
-- Dumped by pg_dump version 15.18 (Debian 15.18-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: period; Type: TYPE; Schema: public; Owner: taskuser
--

CREATE TYPE public.period AS ENUM (
    'YEAR',
    'QUARTER',
    'MONTH',
    'WEEK'
);


ALTER TYPE public.period OWNER TO taskuser;

--
-- Name: priority; Type: TYPE; Schema: public; Owner: taskuser
--

CREATE TYPE public.priority AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH'
);


ALTER TYPE public.priority OWNER TO taskuser;

--
-- Name: taskstatus; Type: TYPE; Schema: public; Owner: taskuser
--

CREATE TYPE public.taskstatus AS ENUM (
    'NEW',
    'IN_PROGRESS',
    'ON_APPROVAL',
    'DONE',
    'OVERDUE'
);


ALTER TYPE public.taskstatus OWNER TO taskuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title character varying NOT NULL,
    description text,
    status public.taskstatus,
    priority public.priority,
    period public.period NOT NULL,
    deadline date NOT NULL,
    department character varying,
    assignee_id integer,
    parent_task_id integer
);


ALTER TABLE public.tasks OWNER TO taskuser;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: taskuser
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO taskuser;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: taskuser
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying NOT NULL,
    role character varying,
    department character varying
);


ALTER TABLE public.users OWNER TO taskuser;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: taskuser
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO taskuser;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: taskuser
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.tasks (id, title, description, status, priority, period, deadline, department, assignee_id, parent_task_id) FROM stdin;
1	Развить партнерство с 5 вузами	Найти и заключить договоры с вузами	IN_PROGRESS	HIGH	YEAR	2026-12-20	Молодые таланты	1	\N
2	Заключить соглашение с МИРЭА	Подготовить договор и подписать	ON_APPROVAL	HIGH	QUARTER	2026-06-30	Молодые таланты	1	\N
3	Подготовить участие в хакатоне	Организовать команду и заявку	IN_PROGRESS	HIGH	MONTH	2026-06-20	Молодые таланты	1	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.users (id, name, role, department) FROM stdin;
1	Виталий	team_lead	Молодые таланты
2	Сергей	employee	АХО
3	Алексей	employee	АХО
4	Денис	team_lead	HR
5	Анна	employee	HR
6	Дмитрий	employee	ИТ
7	Елена	employee	Финансы
\.


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: taskuser
--

SELECT pg_catalog.setval('public.tasks_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: taskuser
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_tasks_id; Type: INDEX; Schema: public; Owner: taskuser
--

CREATE INDEX ix_tasks_id ON public.tasks USING btree (id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: taskuser
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: tasks tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id);


--
-- PostgreSQL database dump complete
--

\unrestrict OvqnfDD7kKSyot4gAOjJK7Ozw24bMYtfaGY3e9wMZdcy2cxhhO91ESBAI2Xxbev

